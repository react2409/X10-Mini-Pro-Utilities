ROOTer for Windows by react2409

Credits go to respective people that created the files used.

I am not responsible for any damage done to your phone whilst you are using this.
You are using it so should know the risks of customising your phone.

Tested On:
Phone: X10 Mini Pro
Android Version: Stock Eclair 2.1
Firmware: 2.1.1.A.0.6
OS: Windows 7 x64

Requirements:
 * Windows PC/Laptop
 * USB Cable
 * USB drivers installed
 * Android Version 2.1 Stock ROM (Firmware 2.1.1.A.0.6 & 2.1.1.C.0.0)

Installer Usage:
 * You need to set your phone in Debugging Mode.
 * Connect your phone to your computer
 * Go to the directory it was extracted to
 * Double-click on the ROOTer.bat

Tutorial:
For a full tutorial go to the GitHub wiki page at:
https://github.com/react2409/X10-Mini-Pro-Utilities/wiki/ROOTer-for-Windows-Tutorial

Links:
XDA thread: http://forum.xda-developers.com/showthread.php?t=1271331

Thanks Go To:
kissmyarch - Tested and troubleshooted.

Changes:
See CHANGES.txt

Hosting:
The only place this file should be hosted at is on the GitHub repo at:
https://github.com/react2409/X10-Mini-Pro-Utilities/tree/master/ROOTer-for-Windowss
