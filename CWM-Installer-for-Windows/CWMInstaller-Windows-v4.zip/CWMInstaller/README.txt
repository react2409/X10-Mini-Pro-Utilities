ClockWorkMod installer.

ONLY FOR X10 MINI PRO. DO NOT USE ON X10 MINI

Credits go to nobodyAtall & D4rKn3sSyS for the actual CWM files.
Credits go to shivenjuneja for SuperOneClick modified version.

Requirements:
Windows PC
USB Cable
Android Version 2.1 Stock ROM

Installer Usage:
You need to set your phone in Debugging Mode.
Connect your phone to your computer
Open up install.bat and follow the instructions inside that.

CWm Usage:
When booting your phone and when the 'Sony Ericsson' letters appear, press and release continuously the 'back' button.
Once you are in the CWM recovery, use the volume keys to navigate upwards / downwards, the 'home' or camera button key to select, the 'back' key to go back.

Links:
Original X10 Mini CWM Thread: http://forum.xda-developers.com/showthread.php?t=1105745
Original X10 Mini Pro CWM Thread: http://forum.xda-developers.com/showthread.php?t=1106146

Changes:
See CHANGES.txt



Please do not rehost this file or modify and re-release without permission.
rect2409 @ XDA