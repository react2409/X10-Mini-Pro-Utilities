ROOTer for use on Linux by rect2409

Credits go to shivenjuneja for the method from SuperOneClick.

This has been tested on: Phone - X10 Mini Pro; OS - Mint 11

Requirements:
*nix PC/Laptop
USB Cable
Android Version 2.1 Stock ROM (Firmware 2.1.1.A.0.6)

Installer Usage:
You need to set your phone in Debugging Mode.
Connect your phone to your computer
Open up terminal and go to the directory.  Start the installer by typing "sh ROOTer.sh"

Thanks Go To:
kissmyarch - Tested for me :)

Changes:
See CHANGES.txt

Hosting:
Only place this file should be hosted is at my Google Project Hosting at:
http://code.google.com/p/rect2409-x10-mini-pro
