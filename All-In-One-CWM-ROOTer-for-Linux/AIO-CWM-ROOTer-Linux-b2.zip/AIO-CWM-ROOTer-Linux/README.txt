All in one solution for installing CWM Recovery and ROOTing your X10 Mini Pro on Linux

ONLY FOR X10 MINI PRO. DO NOT USE ON X10 MINI.

Credits:
nobodyAtall for porting the recovery.tar to our phones.
D4 for the chargemon
Relevant people for the su binary and Superuser.apk
Relevant people for the rageagainsthecage binary

I am not responsible for any damage done to your phone whilst you are using this.
You are using it so should know the risks of customising your phone.

Tested On:
Phone: X10 Mini Pro
Android OS: 2.1 Eclair
Firmware: 2.1.1.A.0.6

Requirements:
 * Linux PC/Laptop
 * USB Cable
 * Android Version 2.1 Stock ROM

Installer Usage:
 * You need to set your phone in Debugging Mode
 * Connect your phone to your computer
 * Open up terminal
 * Go to the directory it was extracted to
 * Start the installer by typing "sh start.sh"

Tutorial:
For a full tutorial go to the GitHub wiki page at:
https://github.com/react2409/X10-Mini-Pro-Utilities/wiki/All-In-One-for-Linux-Tutorial

CWM Usage:
When booting your phone and when the 'Sony Ericsson' letters appear, press and release continuously the 'back' button.
Once you are in the CWM recovery, use the volume keys to navigate upwards / downwards, the 'home' or camera button key to select, the 'back' key to go back.

Links:
ROOTer for Linux Thread: http://forum.xda-developers.com/showthread.php?t=1271331
CWM Installer Thread: http://forum.xda-developers.com/showthread.php?t=1257701
Original X10 Mini CWM Thread: http://forum.xda-developers.com/showthread.php?t=1105745
Original X10 Mini Pro CWM Thread: http://forum.xda-developers.com/showthread.php?t=1106146

Previous Versions: (Version - Released - Downloads)
b1 - 07-Oct-2011 - beta

Changes:
See CHANGES.txt

Hosting:
The only place this file should be hosted at is on the GitHub repo at:
https://github.com/react2409/X10-Mini-Pro-Utilities/tree/master/All-In-One-CWM-ROOTer-for-Linux
